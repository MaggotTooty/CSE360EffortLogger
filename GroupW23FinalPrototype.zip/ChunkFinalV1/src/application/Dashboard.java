package application;



public class Dashboard {
	
//	private Scene scene;
//	
//	Button startStopButton = (Button) scene.lookup("#StartStop");
//    startStopButton.setOnAction(e -> {
//        if (startStopButton.getText().equals("Start Timer")) {
//            startStopButton.setText("Stop Timer");
//        } else {
//            startStopButton.setText("Start Timer");
//        }
//    });
}

